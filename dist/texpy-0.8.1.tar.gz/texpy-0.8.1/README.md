# TexPy

### Descrizione rapida della libreria
Questa libreria e' stata creata da studenti del corso di Laboratorio 3 dell'universita' di Pisa per velocizzare la stesura delle relazioni, contiene funzioni che potrebbero risultare utili pure a corsi come Laboratorio 1 e 2  

### Installazione
scrivere su terminale `pip install texpy`
